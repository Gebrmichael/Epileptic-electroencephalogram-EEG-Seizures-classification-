load E_train_data.mat
load NE_train_data.mat

E_train_data=E_train_data(1:end,:);
NE_train_data=NE_train_data(1:end,:);

e_data=[E_train_data(:,1), E_train_data(:,2)]; %data points
 ne_data=[NE_train_data(:,1), NE_train_data(:,2)]; %data points
 
train_data=[e_data;ne_data];

groups=ones(200,1);
groups(101:end)=0;

plot(e_data(:,1), e_data(:,2), 'b*','MarkerSize',10);
hold on
plot(ne_data(:,1), ne_data(:,2), 'ro','MarkerSize',10);
axis equal
hold on

 k=10;
 cvFolds = crossvalind('Kfold', groups, k);
  cp = classperf(groups); 
  for i = 1:k  
      testIdx = (cvFolds == i); 
       trainIdx = ~testIdx;  
       svmModel = svmtrain(train_data(trainIdx,:), groups(trainIdx),'Kernel_Function','rbf',...
'showplot',true);
       pred = svmclassify(svmModel, train_data(testIdx,:), 'Showplot',true);
        cp = classperf(cp, pred, testIdx);
  end
      %# get accuracy
   cp.CorrectRate
 
    % columns:actual, rows:predicted, last-row: unclassified instances
    cp.CountingMatrix

