save gg;
load gg;
ans=pca(ans);

[m n] = size(ans);
 k=1;
for j=1:n
for i=1:m
gg(k) = ans(i,j);
k = k+1;
end
end 
save gg;
% save ne_pca_data_94