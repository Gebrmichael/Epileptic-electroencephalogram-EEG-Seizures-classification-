function [FeatureSignal] = integrated_code(~) 
    [files,path] = uigetfile('MultiSelect', 'on');
for g = 1 : length(files)
if iscell(files)
    
   data = importdata(fullfile(path,files{g})); 
   
 signal=data;
[A8,D1,D2,D3,D4,D5,D6,D7,D8] = Wavelet_Decomposition(signal,8);


%------------------------------------------------------------------------
overlap = 173; % 0.5 second overlap
WindowLength = 346; % 1 second window length
SignalBlock = floor((length(D5)/overlap)-1);
%Statistical features for wavelet subband D5,D6,D7,D8,A8

[MeanD5,AvgD5,SDD5,MAXD5,MIND5] = Stat_Features(D5,overlap,WindowLength);
[MeanD6,AvgD6,SDD6,MAXD6,MIND6] = Stat_Features(D6,overlap,WindowLength);
[MeanD7,AvgD7,SDD7,MAXD7,MIND7] = Stat_Features(D7,overlap,WindowLength);
[MeanD8,AvgD8,SDD8,MAXD8,MIND8] = Stat_Features(D8,overlap,WindowLength);
[MeanA8,AvgA8,SDA8,MAXA8,MINA8] = Stat_Features(A8,overlap,WindowLength);

FeatureSignal = zeros(SignalBlock,25); % Preallocating for the feature matrix
% Extracts the feature lable from the dataexcel
% Labels =MeanD5,MeanD6,MeanD7,MeanD8,MeanA8,AvgD5,AvgD6,AvgD7,AvgD8,AvgA8,SDD5,SDD6,
% SDD7,SDD8,SDA8
% [num1,FeatureLabel,raw1] = xlsread(Filename,3,'B:B');
%clear num1;
%clear raw1;

FeatureSignal(:,1) = MeanD5;
FeatureSignal(:,2) = MeanD6;
FeatureSignal(:,3) = MeanD7;
FeatureSignal(:,4) = MeanD8;
FeatureSignal(:,5) = MeanA8;

FeatureSignal(:,6) = AvgD5;
FeatureSignal(:,7) = AvgD6;
FeatureSignal(:,8) = AvgD7;
FeatureSignal(:,9) = AvgD8;
FeatureSignal(:,10)= AvgA8;

FeatureSignal(:,11) = SDD5;
FeatureSignal(:,12) = SDD6;
FeatureSignal(:,13) = SDD7;
FeatureSignal(:,14) = SDD8;
FeatureSignal(:,15) = SDA8;

FeatureSignal(:,16) = MAXD5;
FeatureSignal(:,17) = MAXD6;
FeatureSignal(:,18) = MAXD7;
FeatureSignal(:,19) = MAXD8;
FeatureSignal(:,20) = MAXA8;

FeatureSignal(:,21) = MIND5;
FeatureSignal(:,22) = MIND6;
FeatureSignal(:,23) = MIND7;
FeatureSignal(:,24) = MIND8;
FeatureSignal(:,25) = MINA8;

save epileptic_signal
load epileptic_signal

 [m,n] = size(FeatureSignal);
 k=1; 
prefex = 'ne_s';   
filename(:,g) = [prefex '_' num2str(g,'%03d')];     

for j=1:n
for i=1:m      
gm(k) = FeatureSignal(i,j); 
   k = k+1;      
end
end
 eval(['NE_data' num2str(g,'%03d') '=gm']);
 save (filename(:,g))
 
end
end
   clear all
   clc
end

function [Mean,Avg,SD,Max,Min] = Stat_Features( SB,OL,WL)
SignalBlock = floor((length(SB)/OL)-1);
SignalEnd = WL - 1;
% Preallocating matrix for mean, avg and std
Mean = zeros(1,SignalBlock);
Avg = zeros(1,SignalBlock);
SD = zeros(1,SignalBlock);
Max= zeros(1,SignalBlock);
Min=zeros(1,SignalBlock);
i1 = 1;

for i = 1:SignalBlock
i2 = i1+SignalEnd;
%Statistical features for the wavelet subband
Mean(i) = meanabs(SB(i1:i2));
Avg(i) = mean(SB(i1:i2));
SD(i) = std(SB(i1:i2));
Max(i)= max(SB(i1:i2));
Min(i)= max(SB(i1:i2));
i1 = (i2-OL)+1;
end
end                
                                
function [ A8,D1,D2,D3,D4,D5,D6,D7,D8 ] = Wavelet_Decomposition(S,L)

waveletFunction = 'db7';
[C,L] = wavedec(S,L,waveletFunction);
                
% C is the vector formed by concatenating approximation and detail coeeficients at each level. 
% L is the vector that gives the length of each component. 
   %decomposition using DWT
                cD1 = detcoef(C,L,1); 
                cD2 = detcoef(C,L,2); 
                cD3 = detcoef(C,L,3); 
                cD4 = detcoef(C,L,4); 
                cD5 = detcoef(C,L,5); 
                cD6 = detcoef(C,L,6); 
                cD7 = detcoef(C,L,7); 
                cD8 = detcoef(C,L,8);
                cA8 = appcoef(C,L,waveletFunction,8); 

                D1 = wrcoef('d',C,L,waveletFunction,1); 
                D2 = wrcoef('d',C,L,waveletFunction,2); 
                D3 = wrcoef('d',C,L,waveletFunction,3); 
                D4 = wrcoef('d',C,L,waveletFunction,4); 
                D5 = wrcoef('d',C,L,waveletFunction,5); 
                D6 = wrcoef('d',C,L,waveletFunction,6); 
                D7 = wrcoef('d',C,L,waveletFunction,7); 
                D8 = wrcoef('d',C,L,waveletFunction,8); 
                A8 = wrcoef('a',C,L,waveletFunction,8); 
end




