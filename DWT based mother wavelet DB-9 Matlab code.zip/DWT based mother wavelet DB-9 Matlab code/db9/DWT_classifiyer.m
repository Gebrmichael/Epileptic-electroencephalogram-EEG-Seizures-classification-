%======================================Loading data
load E_train_data.mat
load NE_train_data.mat


%======================================Preparing Training data
e_train_data=E_train_data(1:100,:);
ne_train_data=NE_train_data(1:100,:);

 e_data=[e_train_data(:,1), e_train_data(:,2)]; %data points
 ne_data=[ne_train_data(:,1), ne_train_data(:,2)]; %data points
 train_data=[e_data;ne_data];
   
plot(e_data(:,1), e_data(:,2), 'b*','MarkerSize',10);
hold on
plot(ne_data(:,1), ne_data(:,2), 'ro','MarkerSize',10);
axis equal
hold on
 
 
 %=======================================Preparing testing data
 
 e_test_data=E_train_data(81:81,:);
 ne_test_data=NE_train_data(81:end,:);

 e_test=[e_test_data(:,1), e_test_data(:,2)]; 
 ne_test=[ne_test_data(:,1), ne_test_data(:,2)]; 
 
 test_data=[e_test;ne_test];
 
groups=ones(160,1);
groups(81:end)=0;
%==============================================Training and classifing 

 svmModel = svmtrain(train_data, groups,'Showplot',true);
 
 group = svmclassify(svmModel, e_test,'Showplot',true);
      
     